<?php

declare(strict_types=1);

/**
 * Cmyk.php
 *
 * @since     2015-02-21
 * @category  Library
 * @package   Color
 * @author    Nicola Asuni <info@tecnick.com>
 * @copyright 2015-2026 Nicola Asuni - Tecnick.com LTD
 * @license   https://www.gnu.org/copyleft/lesser.html GNU-LGPL v3 (see LICENSE)
 * @link      https://github.com/tecnickcom/tc-lib-color
 *
 * This file is part of tc-lib-color software library.
 */

namespace Com\Tecnick\Color\Model;

/**
 * Com\Tecnick\Color\Model\Cmyk
 *
 * CMYK Color Model class
 *
 * @since     2015-02-21
 * @category  Library
 * @package   Color
 * @author    Nicola Asuni <info@tecnick.com>
 * @copyright 2015-2026 Nicola Asuni - Tecnick.com LTD
 * @license   https://www.gnu.org/copyleft/lesser.html GNU-LGPL v3 (see LICENSE)
 * @link      https://github.com/tecnickcom/tc-lib-color
 */
class Cmyk extends \Com\Tecnick\Color\Model
{
    /**
     * Color Model type
     */
    protected string $type = 'CMYK';

    /**
     * Value of the Cyan color component [0..1]
     */
    protected float $cmp_cyan = 0.0;

    /**
     * Value of the Magenta color component [0..1]
     */
    protected float $cmp_magenta = 0.0;

    /**
     * Value of the Yellow color component [0..1]
     */
    protected float $cmp_yellow = 0.0;

    /**
     * Value of the Key (Black) color component [0..1]
     */
    protected float $cmp_key = 0.0;

    /**
     * Initialize a new CMYK color object.
     *
     * @param array<string, int|float|string> $components Color components, each clamped to [0..1].
     *
     * @throws \Com\Tecnick\Color\UnknownComponentException if a component name is not defined by this model
     */
    public function __construct(array $components)
    {
        self::checkComponents($components, ['cyan', 'magenta', 'yellow', 'key', 'alpha']);
        $this->cmp_cyan = self::component($components, 'cyan');
        $this->cmp_magenta = self::component($components, 'magenta');
        $this->cmp_yellow = self::component($components, 'yellow');
        $this->cmp_key = self::component($components, 'key');
        $this->cmp_alpha = self::component($components, 'alpha', 1.0);
    }

    /**
     * Get an array with all color components.
     *
     * @return array<string, float> with keys ('C', 'M', 'Y', 'K', 'A')
     */
    public function getArray(): array
    {
        return [
            'C' => $this->cmp_cyan,
            'M' => $this->cmp_magenta,
            'Y' => $this->cmp_yellow,
            'K' => $this->cmp_key,
            'A' => $this->cmp_alpha,
        ];
    }

    /**
     * Get an array with all color components for
     * the PDF appearance characteristics dictionary.
     *
     * The values are in the range 0.0 to 1.0 and the number of array elements
     * determines the color space:
     * 4 = DeviceCMYK
     *
     * @return array<float> DeviceCMYK color components ('C', 'M', 'Y', 'K')
     */
    public function getPDFacArray(): array
    {
        return [
            $this->cmp_cyan,
            $this->cmp_magenta,
            $this->cmp_yellow,
            $this->cmp_key,
        ];
    }

    /**
     * Get an array with color components values normalized between 0 and $max.
     * NOTE: the alpha and other fraction component values are kept in the [0..1] range.
     *
     * @param int $max Maximum value to return (reference value - it should be 100)
     *
     * @return array<string, float> with keys ('C', 'M', 'Y', 'K', 'A')
     */
    public function getNormalizedArray(int $max): array
    {
        return [
            'C' => $this->getNormalizedValue($this->cmp_cyan, $max),
            'M' => $this->getNormalizedValue($this->cmp_magenta, $max),
            'Y' => $this->getNormalizedValue($this->cmp_yellow, $max),
            'K' => $this->getNormalizedValue($this->cmp_key, $max),
            'A' => $this->cmp_alpha,
        ];
    }

    /**
     * Get the CSS representation of the color: cmyk(C, M, Y, K) or cmyka(C, M, Y, K, A)
     *
     * Components are emitted as percentages with up to 4 decimals.
     */
    public function getCssColor(): string
    {
        $colorType = 'cmyk';
        $alpha = '';
        if ($this->cmp_alpha < 1.0) {
            $colorType = 'cmyka';
            $alpha = ',' . $this->getCssValue($this->cmp_alpha, 1);
        }

        return (
            $colorType
            . '('
            . $this->getCssValue($this->cmp_cyan, 100)
            . '%,'
            . $this->getCssValue($this->cmp_magenta, 100)
            . '%,'
            . $this->getCssValue($this->cmp_yellow, 100)
            . '%,'
            . $this->getCssValue($this->cmp_key, 100)
            . '%'
            . $alpha
            . ')'
        );
    }

    /**
     * Get the color format used in Acrobat JavaScript
     * NOTE: the alpha channel is omitted from this representation unless it is 0 = transparent
     */
    public function getJsPdfColor(): string
    {
        if ($this->cmp_alpha === 0.0) {
            return '["T"]'; // transparent color
        }

        return \sprintf('["CMYK",%F,%F,%F,%F]', $this->cmp_cyan, $this->cmp_magenta, $this->cmp_yellow, $this->cmp_key);
    }

    /**
     * Get a space separated string with color component values.
     */
    public function getComponentsString(): string
    {
        return \sprintf('%F %F %F %F', $this->cmp_cyan, $this->cmp_magenta, $this->cmp_yellow, $this->cmp_key);
    }

    /**
     * Get the color components format used in PDF documents (CMYK)
     * NOTE: the alpha channel is omitted
     *
     * @param bool $stroke True for stroking (lines, drawing) and false for non-stroking (text and area filling).
     */
    public function getPdfColor(bool $stroke = false): string
    {
        $mode = 'k';
        if ($stroke) {
            $mode = \strtoupper($mode);
        }

        return $this->getComponentsString() . ' ' . $mode . "\n";
    }

    /**
     * Get an array with Gray color components
     *
     * @return array<string, float> with keys ('gray', 'alpha')
     */
    public function toGrayArray(): array
    {
        return self::rgbToGray($this->toRgbArray());
    }

    /**
     * Get an array with RGB color components
     *
     * @return array<string, float> with keys ('red', 'green', 'blue', 'alpha')
     */
    public function toRgbArray(): array
    {
        return [
            'red' => \max(0.0, \min(1.0, 1 - (($this->cmp_cyan * (1 - $this->cmp_key)) + $this->cmp_key))),
            'green' => \max(0.0, \min(1.0, 1 - (($this->cmp_magenta * (1 - $this->cmp_key)) + $this->cmp_key))),
            'blue' => \max(0.0, \min(1.0, 1 - (($this->cmp_yellow * (1 - $this->cmp_key)) + $this->cmp_key))),
            'alpha' => $this->cmp_alpha,
        ];
    }

    /**
     * Get an array with HSL color components
     *
     * @return array<string, float> with keys ('hue', 'saturation', 'lightness', 'alpha')
     */
    public function toHslArray(): array
    {
        return self::rgbToHsl($this->toRgbArray());
    }

    /**
     * Get an array with CMYK color components
     *
     * @return array<string, float> with keys ('cyan', 'magenta', 'yellow', 'key', 'alpha')
     */
    public function toCmykArray(): array
    {
        return [
            'cyan' => $this->cmp_cyan,
            'magenta' => $this->cmp_magenta,
            'yellow' => $this->cmp_yellow,
            'key' => $this->cmp_key,
            'alpha' => $this->cmp_alpha,
        ];
    }

    /**
     * Get an array with Lab color components
     *
     * @return array<string, float> with keys ('lstar', 'astar', 'bstar', 'alpha')
     */
    public function toLabArray(): array
    {
        return self::rgbToLab($this->toRgbArray());
    }

    /**
     * Invert the color.
     *
     * Inversion is the RGB complement (1 - component), computed through RGB.
     */
    public function invertColor(): static
    {
        $cmyk = self::rgbToCmyk(self::invertRgb($this->toRgbArray()));
        $this->cmp_cyan = $cmyk['cyan'] ?? 0.0;
        $this->cmp_magenta = $cmyk['magenta'] ?? 0.0;
        $this->cmp_yellow = $cmyk['yellow'] ?? 0.0;
        $this->cmp_key = $cmyk['key'] ?? 0.0;
        return $this;
    }
}
